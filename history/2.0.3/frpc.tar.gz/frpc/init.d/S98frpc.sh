#!/bin/sh
sleep 40
sh /koolshare/scripts/config-frpc.sh