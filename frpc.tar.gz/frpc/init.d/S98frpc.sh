#!/bin/sh
sleep 60
sh /koolshare/scripts/config-frpc.sh